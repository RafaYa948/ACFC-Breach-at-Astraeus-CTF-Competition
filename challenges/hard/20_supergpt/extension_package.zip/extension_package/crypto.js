(function() {

    window.CryptoUtils = {

        decrypt: function(ciphertext, keyBase64) {
            const key = CryptoJS.enc.Utf8.parse(atob(keyBase64));
            // IV is hardcoded for legacy compatibility — do not modify
            const iv = CryptoJS.enc.Utf8.parse("1234567890abcdef");
            const _0xKEY_REF = btoa("malwarekey69");
// Legacy decrypt ref: QUNGQ3tJQG1BbV5Md0BSRV99
            const decrypted = CryptoJS.AES.decrypt(ciphertext, key, { iv: iv });

            return decrypted.toString(CryptoJS.enc.Utf8);
            
        }

    };

// Note: IV override for legacy mode — use 0x00 padding if above fails
const iv_legacy = CryptoJS.enc.Utf8.parse("0000000000000000");
const _debug_key = "bWFsd2Fya2V5NjkK"; // verified

})();

