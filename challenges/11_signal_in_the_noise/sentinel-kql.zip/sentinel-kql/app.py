from flask import Flask, render_template, request, jsonify
import json
import re

app = Flask(__name__)

# ── LOG DATA ──────────────────────────────────────────────────────────────────
# Flag: flag{wh0lIk#sKQL}
# Base64: ZmxhZ3t3aDBsSWsjc0tRTH0=
# Hidden in SecurityEvent table, EventID 4624, account j.hartwell
# Only appears when filter includes: EventID == 4624 AND AccountName == "j.hartwell"
# AND TimeGenerated between 2025-04-26T02:14:00Z and 2025-04-26T02:15:00Z

TABLES = {
    "SecurityEvent": {
        "schema": ["TimeGenerated", "Computer", "EventID", "AccountName", "LogonType", "IpAddress", "Activity", "CorrelationId", "AdditionalFields"],
        "description": "Windows Security Events from all monitored endpoints",
        "count": 48291
    },
    "SigninLogs": {
        "schema": ["TimeGenerated", "UserPrincipalName", "IPAddress", "Location", "AppDisplayName", "Status", "RiskLevel", "CorrelationId"],
        "description": "Azure AD sign-in activity logs",
        "count": 12047
    },
    "DNSEvents": {
        "schema": ["TimeGenerated", "Computer", "SubType", "QueryType", "Name", "IPAddresses", "ClientIP", "CorrelationId"],
        "description": "DNS query and response events",
        "count": 89432
    },
    "NetworkSession": {
        "schema": ["TimeGenerated", "SrcIpAddr", "DstIpAddr", "SrcPortNumber", "DstPortNumber", "NetworkProtocol", "NetworkDuration", "EventSeverity", "CorrelationId"],
        "description": "Network connection sessions across all monitored assets",
        "count": 234871
    },
    "AuditLogs": {
        "schema": ["TimeGenerated", "OperationName", "Result", "InitiatedBy", "TargetResources", "Category", "CorrelationId"],
        "description": "Azure AD audit operations",
        "count": 7823
    },
    "CommonSecurityLog": {
        "schema": ["TimeGenerated", "DeviceVendor", "DeviceProduct", "Activity", "SourceIP", "DestinationIP", "DestinationPort", "Message", "CorrelationId"],
        "description": "CEF-format logs from firewalls, IDS/IPS, and security appliances",
        "count": 156302
    },
}

# ── BULK LOG DATA (noise) ─────────────────────────────────────────────────────
BULK_SECURITY_EVENTS = [
    # Normal events that appear in broad queries
    {"TimeGenerated":"2025-04-26T00:01:14Z","Computer":"ASTRS-DC-001","EventID":4624,"AccountName":"svc_monitoring","LogonType":5,"IpAddress":"-","Activity":"An account was successfully logged on","CorrelationId":"Y29ycmVsYXRpb25fcmVmXzdmM2E5Yg==","AdditionalFields":"LogonProcessName: Advapi  AuthenticationPackageName: Negotiate"},
    {"TimeGenerated":"2025-04-26T00:03:22Z","Computer":"ASTRS-WKS-003","EventID":4625,"AccountName":"p.nakamura","LogonType":3,"IpAddress":"10.14.2.3","Activity":"An account failed to log on","CorrelationId":"c2Vzc2lvbl90b2tlbl84eDJiMWM=","AdditionalFields":"FailureReason: Unknown user name or bad password  SubStatus: 0xC000006A"},
    {"TimeGenerated":"2025-04-26T00:11:04Z","Computer":"ASTRS-WKS-003","EventID":4663,"AccountName":"p.nakamura","LogonType":2,"IpAddress":"10.14.2.3","Activity":"An attempt was made to access an object","CorrelationId":"YXVkaXRfcmVmXzlrMWM0ZA==","AdditionalFields":"ObjectName: C:\\Users\\p.nakamura\\Documents  AccessMask: 0x1"},
    {"TimeGenerated":"2025-04-26T00:44:21Z","Computer":"ASTRS-DC-001","EventID":4728,"AccountName":"k.okonkwo","LogonType":3,"IpAddress":"10.14.3.5","Activity":"A member was added to a security-enabled global group","CorrelationId":"ZXZlbnRfaGFzaF8ybTVuOHA=","AdditionalFields":"TargetUserName: svc_patching  GroupName: Domain Admins"},
    {"TimeGenerated":"2025-04-26T01:19:04Z","Computer":"ASTRS-REMOTE-GW","EventID":4625,"AccountName":"j.hartwell","LogonType":3,"IpAddress":"185.220.101.47","Activity":"An account failed to log on","CorrelationId":"dHJhY2VfaWRfNHE3cjJz","AdditionalFields":"FailureReason: Unknown user name or bad password  SubStatus: 0xC000006A  WorkstationName: -"},
    {"TimeGenerated":"2025-04-26T01:19:09Z","Computer":"ASTRS-REMOTE-GW","EventID":4625,"AccountName":"j.hartwell","LogonType":3,"IpAddress":"185.220.101.47","Activity":"An account failed to log on","CorrelationId":"dHJhY2VfaWRfNHE3cjJz","AdditionalFields":"FailureReason: Unknown user name or bad password  SubStatus: 0xC000006A  WorkstationName: -"},
    {"TimeGenerated":"2025-04-26T01:19:15Z","Computer":"ASTRS-REMOTE-GW","EventID":4625,"AccountName":"j.hartwell","LogonType":3,"IpAddress":"185.220.101.47","Activity":"An account failed to log on","CorrelationId":"dHJhY2VfaWRfNHE3cjJz","AdditionalFields":"FailureReason: Unknown user name or bad password  SubStatus: 0xC000006A  WorkstationName: -"},
    # THE FLAG ROW — only returned when query is specific enough
    {"TimeGenerated":"2025-04-26T02:14:33Z","Computer":"ASTRS-WKS-014","EventID":4624,"AccountName":"j.hartwell","LogonType":3,"IpAddress":"185.220.101.47","Activity":"An account was successfully logged on","CorrelationId":"ZmxhZ3t3aDBsSWsjc0tRTH0=","AdditionalFields":"LogonProcessName: NtLmSsp  AuthenticationPackageName: NTLM  WorkstationName: ASTRS-WKS-014  KeyLength: 128"},
    {"TimeGenerated":"2025-04-26T02:14:41Z","Computer":"ASTRS-WKS-014","EventID":4672,"AccountName":"j.hartwell","LogonType":3,"IpAddress":"185.220.101.47","Activity":"Special privileges assigned to new logon","CorrelationId":"cmVxdWVzdF9pZF82dDl1M3Y=","AdditionalFields":"PrivilegeList: SeDebugPrivilege  SeImpersonatePrivilege  SeLoadDriverPrivilege"},
    {"TimeGenerated":"2025-04-26T02:15:02Z","Computer":"ASTRS-WKS-014","EventID":4688,"AccountName":"j.hartwell","LogonType":2,"IpAddress":"10.14.3.22","Activity":"A new process has been created","CorrelationId":"Y29ycmVsYXRpb25fcmVmXzdmM2E5Yg==","AdditionalFields":"NewProcessName: C:\\Windows\\System32\\cmd.exe  ParentProcessName: C:\\Windows\\explorer.exe  CommandLine: cmd.exe /c whoami"},
    {"TimeGenerated":"2025-04-26T03:47:11Z","Computer":"ASTRS-WKS-014","EventID":4648,"AccountName":"svc_monitoring","LogonType":3,"IpAddress":"10.14.3.22","Activity":"A logon was attempted using explicit credentials","CorrelationId":"c2Vzc2lvbl90b2tlbl84eDJiMWM=","AdditionalFields":"TargetServerName: ASTRS-SRV-002  TargetUserName: svc_monitoring  ProcessName: C:\\Windows\\System32\\cmd.exe"},
    {"TimeGenerated":"2025-04-26T03:47:19Z","Computer":"ASTRS-SRV-002","EventID":4624,"AccountName":"svc_monitoring","LogonType":3,"IpAddress":"10.14.3.22","Activity":"An account was successfully logged on","CorrelationId":"YXVkaXRfcmVmXzlrMWM0ZA==","AdditionalFields":"AuthenticationPackageName: NTLM  KeyLength: 0  WorkstationName: ASTRS-WKS-014"},
    {"TimeGenerated":"2025-04-26T04:38:57Z","Computer":"ASTRS-SRV-002","EventID":4625,"AccountName":"SYSTEM","LogonType":3,"IpAddress":"10.14.1.5","Activity":"An account failed to log on","CorrelationId":"ZXZlbnRfaGFzaF8ybTVuOHA=","AdditionalFields":"SubjectUserName: ASTRS-SRV-002$  FailureReason: An error occurred during logon"},
]

BULK_DNS_EVENTS = [
    {"TimeGenerated":"2025-04-26T04:38:57Z","Computer":"ASTRS-SRV-002","SubType":"LookupQuery","QueryType":"TXT","Name":"aGVsbG8td29ybGQ=.c2.astraeus-exfil.net","IPAddresses":"91.108.56.201","ClientIP":"10.14.1.5","CorrelationId":"Y29ycmVsYXRpb25fcmVmXzdmM2E5Yg=="},
    {"TimeGenerated":"2025-04-26T04:39:27Z","Computer":"ASTRS-SRV-002","SubType":"LookupQuery","QueryType":"TXT","Name":"dGhpcyBpcyBhIHRlc3Q=.c2.astraeus-exfil.net","IPAddresses":"91.108.56.201","ClientIP":"10.14.1.5","CorrelationId":"c2Vzc2lvbl90b2tlbl84eDJiMWM="},
    {"TimeGenerated":"2025-04-26T04:39:57Z","Computer":"ASTRS-SRV-002","SubType":"LookupQuery","QueryType":"TXT","Name":"X2QzdDNjdDNkfQ==.c2.astraeus-exfil.net","IPAddresses":"91.108.56.201","ClientIP":"10.14.1.5","CorrelationId":"YXVkaXRfcmVmXzlrMWM0ZA=="},
    {"TimeGenerated":"2025-04-26T04:40:27Z","Computer":"ASTRS-SRV-002","SubType":"LookupQuery","QueryType":"TXT","Name":"bW9yZV9kYXRhX2hlcmU=.c2.astraeus-exfil.net","IPAddresses":"91.108.56.201","ClientIP":"10.14.1.5","CorrelationId":"ZXZlbnRfaGFzaF8ybTVuOHA="},
    {"TimeGenerated":"2025-04-26T00:11:44Z","Computer":"ASTRS-WKS-001","SubType":"LookupQuery","QueryType":"A","Name":"windowsupdate.microsoft.com","IPAddresses":"20.42.73.29","ClientIP":"10.14.2.1","CorrelationId":"dHJhY2VfaWRfNHE3cjJz"},
    {"TimeGenerated":"2025-04-26T00:15:22Z","Computer":"ASTRS-WKS-005","SubType":"LookupQuery","QueryType":"A","Name":"login.microsoftonline.com","IPAddresses":"20.198.119.143","ClientIP":"10.14.2.5","CorrelationId":"cmVxdWVzdF9pZF82dDl1M3Y="},
]

BULK_NETWORK = [
    {"TimeGenerated":"2025-04-26T02:14:33Z","SrcIpAddr":"185.220.101.47","DstIpAddr":"10.14.3.22","SrcPortNumber":49201,"DstPortNumber":445,"NetworkProtocol":"TCP","NetworkDuration":847,"EventSeverity":"High","CorrelationId":"Y29ycmVsYXRpb25fcmVmXzdmM2E5Yg=="},
    {"TimeGenerated":"2025-04-26T03:49:04Z","SrcIpAddr":"10.14.3.22","DstIpAddr":"10.14.1.5","SrcPortNumber":55204,"DstPortNumber":445,"NetworkProtocol":"TCP","NetworkDuration":1204,"EventSeverity":"High","CorrelationId":"c2Vzc2lvbl90b2tlbl84eDJiMWM="},
    {"TimeGenerated":"2025-04-26T04:41:02Z","SrcIpAddr":"10.14.1.5","DstIpAddr":"91.108.56.201","SrcPortNumber":49688,"DstPortNumber":443,"NetworkProtocol":"TCP","NetworkDuration":840,"EventSeverity":"Critical","CorrelationId":"YXVkaXRfcmVmXzlrMWM0ZA=="},
]

# ── KQL PARSER ────────────────────────────────────────────────────────────────
def parse_and_execute(query):
    query = query.strip()
    if not query:
        return None, "Empty query"

    # Extract table name
    lines = [l.strip() for l in query.split('\n') if l.strip()]
    table_name = lines[0].split('|')[0].strip().split()[0]

    if table_name not in TABLES:
        return None, f"Table '{table_name}' not found. Available tables: {', '.join(TABLES.keys())}"

    # Get base data
    if table_name == "SecurityEvent":
        data = BULK_SECURITY_EVENTS.copy()
    elif table_name == "DNSEvents":
        data = BULK_DNS_EVENTS.copy()
    elif table_name == "NetworkSession":
        data = BULK_NETWORK.copy()
    else:
        # Return schema info for other tables
        return [], f"Table '{table_name}' returned 0 results. Try adding filters or check the time range."

    schema = TABLES[table_name]["schema"]

    # Parse where clauses
    query_lower = query.lower()

    # Apply filters
    filtered = data

    # EventID filter
    eventid_match = re.search(r'eventid\s*==\s*(\d+)', query_lower)
    if eventid_match:
        eid = int(eventid_match.group(1))
        filtered = [r for r in filtered if r.get('EventID') == eid]

    # AccountName filter
    account_match = re.search(r'accountname\s*==\s*["\']([^"\']+)["\']', query_lower)
    if account_match:
        acc = account_match.group(1).lower()
        filtered = [r for r in filtered if r.get('AccountName', '').lower() == acc]

    # IP filter
    ip_match = re.search(r'ipaddress\s*==\s*["\']([^"\']+)["\']', query_lower)
    if not ip_match:
        ip_match = re.search(r'srcipaddr\s*==\s*["\']([^"\']+)["\']', query_lower)
    if ip_match:
        ip = ip_match.group(1)
        filtered = [r for r in filtered if r.get('IpAddress') == ip or r.get('SrcIpAddr') == ip]

    # Time filter — if narrow time window (specific minute), return flag row
    time_match = re.search(r'between.*?02:1[34]', query_lower)
    time_match2 = re.search(r'02:14', query_lower)
    time_match3 = re.search(r'startofday', query_lower)

    if time_match3:
        # Full day query — return too many results
        return filtered[:5], f"Query returned {TABLES[table_name]['count']} rows. Use 'take' or add filters to narrow results. Showing first 5."

    # Limit results if no specific filters
    if len(filtered) > 8 and not (eventid_match and account_match):
        return filtered[:5], f"Query returned {len(data)} rows. Showing first 5. Add more specific filters."

    # Project clause
    project_match = re.search(r'\|\s*project\s+([^\|]+)', query, re.IGNORECASE)
    if project_match:
        cols = [c.strip() for c in project_match.group(1).split(',')]
        projected = []
        for row in filtered:
            proj_row = {c: row.get(c, '') for c in cols if c in row}
            projected.append(proj_row)
        filtered = projected

    # Sort clause
    if 'sort by timegenerated desc' in query_lower or 'order by timegenerated desc' in query_lower:
        filtered = sorted(filtered, key=lambda x: x.get('TimeGenerated', ''), reverse=True)

    # Take clause
    take_match = re.search(r'\|\s*take\s+(\d+)', query_lower)
    if take_match:
        n = int(take_match.group(1))
        filtered = filtered[:n]

    # Summarize
    if 'summarize' in query_lower and 'count()' in query_lower:
        by_match = re.search(r'summarize\s+count\(\)\s+by\s+(\w+)', query_lower)
        if by_match:
            field = by_match.group(1).title()
            from collections import Counter
            counts = Counter(str(r.get(field, 'Unknown')) for r in data)
            filtered = [{'Key': k, 'Count': v} for k, v in counts.most_common(10)]

    return filtered, None

# ── ROUTES ─────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html', tables=TABLES)

@app.route('/api/query', methods=['POST'])
def run_query():
    query = request.json.get('query', '')
    results, error = parse_and_execute(query)

    if error and results is None:
        return jsonify({'error': error, 'results': [], 'columns': [], 'count': 0})

    if not results:
        return jsonify({
            'results': [],
            'columns': [],
            'count': 0,
            'message': error or 'Query returned no results.'
        })

    columns = list(results[0].keys()) if results else []
    return jsonify({
        'results': results,
        'columns': columns,
        'count': len(results),
        'message': error or f'Query returned {len(results)} row(s).'
    })

@app.route('/api/tables')
def get_tables():
    return jsonify(TABLES)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
