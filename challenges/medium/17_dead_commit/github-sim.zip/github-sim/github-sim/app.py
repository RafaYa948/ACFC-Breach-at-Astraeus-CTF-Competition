from flask import Flask, render_template, request, jsonify, redirect
import base64

app = Flask(__name__)

# ── REPO DATA ──────────────────────────────────────────────────────────────────
OWNER = "siti-zubaida"
REPO = "astraeus-api"
DESCRIPTION = "Internal REST API for Astraeus-9 station management and crew operations"
DEFAULT_BRANCH = "master"

# ── COMMITS ────────────────────────────────────────────────────────────────────
COMMITS = [
    {
        "hash": "1502437c695dd5233b51afa9798d4b9654e73eeb",
        "short": "1502437",
        "message": "docs: update security notice",
        "author": "Siti Zubaida",
        "email": "siti.zubaida@astraeus9.ops",
        "avatar": "SZ",
        "date": "2025-04-26T02:01:14Z",
        "date_display": "Apr 26, 2025",
        "verified": False,
        "diff": [
            {"file": "README.md", "additions": 2, "deletions": 1, "chunks": [
                {"header": "@@ -10,6 +10,8 @@ pip install -r requirements.txt", "lines": [
                    {"type": "context", "content": " ## Security Notice"},
                    {"type": "context", "content": " "},
                    {"type": "add", "content": "+All sensitive configuration is managed via environment variables."},
                    {"type": "add", "content": "+Credentials are never stored in this repository."},
                    {"type": "del", "content": "-All sensitive data removed."},
                    {"type": "context", "content": " "},
                ]}
            ]}
        ]
    },
    {
        "hash": "20530b651383c58949934111533714b0ac4bf67f",
        "short": "20530b6",
        "message": "refactor: add logging and crew endpoint",
        "author": "Siti Zubaida",
        "email": "siti.zubaida@astraeus9.ops",
        "avatar": "SZ",
        "date": "2025-04-26T01:14:07Z",
        "date_display": "Apr 26, 2025",
        "verified": False,
        "diff": [
            {"file": "app.py", "additions": 14, "deletions": 3, "chunks": [
                {"header": "@@ -1,8 +1,22 @@", "lines": [
                    {"type": "context", "content": " from flask import Flask, request, jsonify"},
                    {"type": "context", "content": " import config"},
                    {"type": "add", "content": "+import logging"},
                    {"type": "context", "content": " "},
                    {"type": "context", "content": " app = Flask(__name__)"},
                    {"type": "add", "content": "+logging.basicConfig(level=logging.INFO)"},
                    {"type": "add", "content": "+"},
                    {"type": "add", "content": "+@app.route('/api/crew')"},
                    {"type": "add", "content": "+def crew():"},
                    {"type": "add", "content": "+    return jsonify({'crew': [], 'total': 0})"},
                ]}
            ]}
        ]
    },
    {
        "hash": "23ece101ead74705a390d37d72efcce113bdb9d7",
        "short": "23ece10",
        "message": "hotfix: increase timeout and retry limits",
        "author": "Siti Zubaida",
        "email": "siti.zubaida@astraeus9.ops",
        "avatar": "SZ",
        "date": "2025-04-26T00:33:11Z",
        "date_display": "Apr 26, 2025",
        "verified": False,
        "diff": [
            {"file": "config.py", "additions": 5, "deletions": 2, "chunks": [
                {"header": "@@ -8,8 +8,11 @@", "lines": [
                    {"type": "context", "content": " API_VERSION = 'v2.1'"},
                    {"type": "del", "content": "-API_TIMEOUT = 30"},
                    {"type": "del", "content": "-MAX_RETRIES = 3"},
                    {"type": "add", "content": "+API_TIMEOUT = 60"},
                    {"type": "add", "content": "+MAX_RETRIES = 5"},
                    {"type": "context", "content": " "},
                    {"type": "add", "content": "+# telemetry ref: bm90aGluZ190b19zZWVfaGVyZQ=="},
                    {"type": "add", "content": "+TELEMETRY_INTERVAL = 300"},
                ]}
            ]}
        ]
    },
    {
        "hash": "da6f8c1b6138f97e99f39e4418860b6b2a12bede",
        "short": "da6f8c1",
        "message": "initial commit",
        "author": "Siti Zubaida",
        "email": "siti.zubaida@astraeus9.ops",
        "avatar": "SZ",
        "date": "2025-04-25T23:11:04Z",
        "date_display": "Apr 25, 2025",
        "verified": False,
        "diff": [
            {"file": "README.md", "additions": 20, "deletions": 0, "chunks": []},
            {"file": "app.py", "additions": 15, "deletions": 0, "chunks": []},
            {"file": "config.py", "additions": 18, "deletions": 0, "chunks": []},
            {"file": "requirements.txt", "additions": 4, "deletions": 0, "chunks": []},
            {"file": ".gitignore", "additions": 8, "deletions": 0, "chunks": []},
        ]
    },
]

# ── FILES ──────────────────────────────────────────────────────────────────────
FILES = {
    "README.md": {
        "content": """# Astraeus-9 Internal API

Internal REST API for station management and crew operations.
Access restricted to authorised station personnel only.

## Setup

```bash
pip install -r requirements.txt
python3 app.py
```

## Security Notice

All sensitive configuration is managed via environment variables.
Credentials are never stored in this repository.
All previous sensitive data has been removed.""",
        "size": "612 B",
        "lines": 20,
        "type": "markdown"
    },
    "app.py": {
        "content": """from flask import Flask, request, jsonify
import config
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

@app.route('/api/status')
def status():
    return jsonify({
        "status": "operational",
        "station": "Astraeus-9",
        "version": config.API_VERSION
    })

@app.route('/api/auth', methods=['POST'])
def auth():
    data = request.json
    if not data or 'username' not in data:
        return jsonify({"error": "Missing credentials"}), 400
    logging.info(f"Auth attempt: {data.get('username')}")
    return jsonify({"token": "...", "expires_in": config.JWT_EXPIRY})

@app.route('/api/crew')
def crew():
    return jsonify({"crew": [], "total": 0})

if __name__ == '__main__':
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)""",
        "size": "671 B",
        "lines": 28,
        "type": "python"
    },
    "config.py": {
        "content": """import os

DEBUG = False
HOST = "0.0.0.0"
PORT = 8080
API_VERSION = "v2.1"
API_TIMEOUT = 60
MAX_RETRIES = 5

DB_HOST = os.environ.get("DB_HOST", "localhost")
DB_PORT = int(os.environ.get("DB_PORT", 5432))
DB_NAME = os.environ.get("DB_NAME", "astraeus_db")
DB_USER = os.environ.get("DB_USER", "")
DB_PASS = os.environ.get("DB_PASS", "")

JWT_EXPIRY = 3600
SESSION_TIMEOUT = 1800

# Fake key for testing only — not real
API_KEY = "sk-astraeus-XXXX-XXXX-XXXX"

# telemetry ref: bm90aGluZ190b19zZWVfaGVyZQ==
TELEMETRY_INTERVAL = 300""",
        "size": "448 B",
        "lines": 22,
        "type": "python"
    },
    "requirements.txt": {
        "content": """flask==2.3.3
requests==2.31.0
python-dotenv==1.0.0
pyjwt==2.8.0""",
        "size": "71 B",
        "lines": 4,
        "type": "text"
    },
    ".gitignore": {
        "content": """__pycache__/
*.pyc
.env
.DS_Store
venv/
*.key
*.pem""",
        "size": "52 B",
        "lines": 7,
        "type": "text"
    },
}

# ── STASH DATA (hidden — only via /stash endpoint) ────────────────────────────
STASH = {
    "ref": "stash@{0}",
    "message": "wip: cleanup notes before deployment",
    "date": "2025-04-26T01:38:55Z",
    "author": "Siti Zubaida",
    "diff": """diff --git a/dev_notes.txt b/dev_notes.txt
new file mode 100644
index 0000000..3a9f2c1
--- /dev/null
+++ b/dev_notes.txt
@@ -0,0 +1,8 @@
+TODO before next push:
+- rotate all api keys
+- check env vars are loading correctly
+- remove temp credentials
+
+partial recovery ref: ZmxhZ3tuM3Yzcl9jMG1tMXQ=
+this needs to be cleaned up before prod deployment
"""
}

# ── DANGLING COMMIT (hidden — only via /security or fsck endpoint) ─────────────
DANGLING = {
    "hash": "85efa82d6cd04e1ba2732d7ed4485d2cba3a1a9a",
    "short": "85efa82",
    "message": "temp: add credentials for local testing",
    "author": "Siti Zubaida",
    "date": "2025-04-26T01:52:44Z",
    "diff": """diff --git a/credentials.py b/credentials.py
new file mode 100644
index 0000000..7c3d9f2
--- /dev/null
+++ b/credentials.py
@@ -0,0 +1,9 @@
+# TEMP - local testing only
+# DO NOT PUSH THIS FILE
+
+API_KEY = "sk-astraeus-9f3a2b8c4d1e6f7a"
+API_SECRET = "astraeus9-internal-2025"
+DB_USER = "astraeus_admin"
+DB_PASS_HEX = "5f733363723374735f30727d"
+BACKUP_KEY = "bk-xK9mP2nQ8rL5vT3w"
+MONITORING_TOKEN = "mon-7c3d9f2a1b4e8g6h"
"""
}

# ── ROUTES ─────────────────────────────────────────────────────────────────────

@app.route('/')
def home():
    return redirect(f'/{OWNER}/{REPO}')

@app.route(f'/{OWNER}/{REPO}')
def repo_home():
    return render_template('repo/index.html',
        owner=OWNER, repo=REPO, description=DESCRIPTION,
        files=FILES, commits=COMMITS, branch=DEFAULT_BRANCH,
        latest_commit=COMMITS[0])

@app.route(f'/{OWNER}/{REPO}/commits/<branch>')
@app.route(f'/{OWNER}/{REPO}/commits')
def commits(branch=DEFAULT_BRANCH):
    return render_template('repo/commits.html',
        owner=OWNER, repo=REPO, commits=COMMITS, branch=branch)

@app.route(f'/{OWNER}/{REPO}/commit/<hash>')
def commit_detail(hash):
    commit = next((c for c in COMMITS if c['hash'].startswith(hash) or c['short'] == hash), None)
    if not commit:
        return render_template('repo/404.html', owner=OWNER, repo=REPO), 404
    return render_template('repo/commit.html',
        owner=OWNER, repo=REPO, commit=commit)

@app.route(f'/{OWNER}/{REPO}/blob/<branch>/<path:filepath>')
def file_view(branch, filepath):
    file = FILES.get(filepath)
    if not file:
        return render_template('repo/404.html', owner=OWNER, repo=REPO), 404
    return render_template('repo/file.html',
        owner=OWNER, repo=REPO, filepath=filepath,
        file=file, branch=branch, commits=COMMITS)

@app.route(f'/{OWNER}/{REPO}/tree/<branch>')
def tree(branch):
    return redirect(f'/{OWNER}/{REPO}')

@app.route(f'/{OWNER}/{REPO}/issues')
def issues():
    return render_template('repo/issues.html', owner=OWNER, repo=REPO)

@app.route(f'/{OWNER}/{REPO}/pulls')
def pulls():
    return render_template('repo/pulls.html', owner=OWNER, repo=REPO)

@app.route(f'/{OWNER}/{REPO}/actions')
def actions():
    return render_template('repo/actions.html', owner=OWNER, repo=REPO)

@app.route(f'/{OWNER}/{REPO}/security')
def security():
    return render_template('repo/security.html',
        owner=OWNER, repo=REPO, dangling=DANGLING)

@app.route(f'/{OWNER}/{REPO}/network')
def network():
    return render_template('repo/network.html', owner=OWNER, repo=REPO, commits=COMMITS)

@app.route(f'/{OWNER}/{REPO}/pulse')
def pulse():
    return render_template('repo/pulse.html', owner=OWNER, repo=REPO)

@app.route(f'/{OWNER}/{REPO}/settings')
def settings():
    return render_template('repo/settings.html', owner=OWNER, repo=REPO)

@app.route(f'/{OWNER}/{REPO}/stash')
def stash():
    return render_template('repo/stash.html',
        owner=OWNER, repo=REPO, stash=STASH)

@app.route(f'/{OWNER}/{REPO}/reflog')
def reflog():
    return render_template('repo/reflog.html',
        owner=OWNER, repo=REPO, commits=COMMITS, dangling=DANGLING)

@app.route(f'/{OWNER}/{REPO}/commit/<hash>/dangling')
def dangling_commit(hash):
    if hash == DANGLING['hash'][:len(hash)]:
        return render_template('repo/commit.html',
            owner=OWNER, repo=REPO, commit={
                **DANGLING,
                'short': DANGLING['short'],
                'diff': [{"file": "credentials.py", "additions": 9, "deletions": 0,
                    "chunks": [{"header": "@@ -0,0 +1,9 @@", "lines": [
                        {"type": "add", "content": "+# TEMP - local testing only"},
                        {"type": "add", "content": "+# DO NOT PUSH THIS FILE"},
                        {"type": "add", "content": "+"},
                        {"type": "add", "content": "+API_KEY = \"sk-astraeus-9f3a2b8c4d1e6f7a\""},
                        {"type": "add", "content": "+API_SECRET = \"astraeus9-internal-2025\""},
                        {"type": "add", "content": "+DB_USER = \"astraeus_admin\""},
                        {"type": "add", "content": "+DB_PASS_HEX = \"5f733363723374735f30727d\""},
                        {"type": "add", "content": "+BACKUP_KEY = \"bk-xK9mP2nQ8rL5vT3w\""},
                        {"type": "add", "content": "+MONITORING_TOKEN = \"mon-7c3d9f2a1b4e8g6h\""},
                    ]}]
                }],
                'verified': False,
                'date_display': 'Apr 26, 2025',
                'avatar': 'SZ',
                'dangling': True
            })
    return render_template('repo/404.html', owner=OWNER, repo=REPO), 404

@app.route(f'/{OWNER}')
def user_profile():
    return render_template('repo/profile.html', owner=OWNER, repo=REPO)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
