from flask import Flask, render_template, request, jsonify
import time
import random

app = Flask(__name__)

# ── FLAG ──────────────────────────────────────────────────────────────────────
# flag{MeM0rYduMPiSfuNn}
# base64: ZmxhZ3tNZU0wcllkdU1QaVNmdU5ufQ==
# Hidden in windows.strings --pid 3841 output at line 847
# Red herring in windows.malfind: ZmxhZ3tNZU0wclk= → flag{MeM0rY (incomplete)
# Red herring in registry: ZmxhZ3t3cjBuZ19wYXRoX2FuYWx5c3R9 → flag{wr0ng_path_analyst}

def make_hex_dump(start_addr, data_hint="", rows=12):
    """Generate realistic hex dump rows"""
    lines = []
    random.seed(42)
    for i in range(rows):
        addr = start_addr + (i * 16)
        if i == 5 and data_hint:
            # Embed the hint bytes
            raw = list(data_hint.encode()[:16].ljust(16, b'\x00'))
        else:
            raw = [random.randint(0, 255) for _ in range(16)]
        hex_part = ' '.join(f'{b:02x}' for b in raw)
        ascii_part = ''.join(chr(b) if 32 <= b < 127 else '.' for b in raw)
        lines.append(f"0x{addr:08x}  {hex_part}  {ascii_part}")
    return '\n'.join(lines)

COMMANDS = {
    "windows.info": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
Variable	Value

Kernel Base	0xf80002a52000
DTB	0x187000
Symbols	file:///volatility3/symbols/windows/ntkrnlmp.pdb/3844DBB920174967BE7AA4A2C20430FA-2.json
Is64Bit	True
IsPAE	False
layer_name	0 WindowsIntel32e
memory_layer	1 FileLayer
KdVersionBlock	0xf80002c3f0f8
Major/Minor	15.7601
MachineType	34404
KeNumberProcessors	4
SystemTime	2025-04-26 02:15:44 UTC
NtSystemRoot	C:\\Windows
NtProductType	NtProductWinNt
NtMajorVersion	6
NtMinorVersion	1
PE MajorOperatingSystemVersion	6
PE MinorOperatingSystemVersion	1
PE Machine	34404
PE TimeDateStamp	Thu Aug 22 08:13:03 2019
""",

    "windows.pslist": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
PID	PPID	ImageFileName	Offset	Threads	Handles	SessionId	Wow64	CreateTime	ExitTime

4	0	System	0xfa8000c9b040	95	411	N/A	False	2025-04-26 00:01:14 UTC	N/A
268	4	smss.exe	0xfa8001379980	2	29	N/A	False	2025-04-26 00:01:14 UTC	N/A
356	348	csrss.exe	0xfa800133b900	9	340	0	False	2025-04-26 00:01:15 UTC	N/A
396	388	wininit.exe	0xfa8001370b30	3	75	0	False	2025-04-26 00:01:15 UTC	N/A
404	388	csrss.exe	0xfa800197d060	11	375	1	False	2025-04-26 00:01:15 UTC	N/A
448	396	services.exe	0xfa80019b2b30	11	201	0	False	2025-04-26 00:01:15 UTC	N/A
456	396	lsass.exe	0xfa80019b6b30	7	591	0	False	2025-04-26 00:01:15 UTC	N/A
464	396	lsm.exe	0xfa80019c4060	10	142	0	False	2025-04-26 00:01:15 UTC	N/A
568	448	svchost.exe	0xfa8001a2eb30	10	347	0	False	2025-04-26 00:01:15 UTC	N/A
636	448	svchost.exe	0xfa8001a6cb30	8	271	0	False	2025-04-26 00:01:16 UTC	N/A
704	448	svchost.exe	0xfa8001aafb30	22	540	0	False	2025-04-26 00:01:16 UTC	N/A
816	448	svchost.exe	0xfa8001b13060	14	365	0	False	2025-04-26 00:01:16 UTC	N/A
856	448	svchost.exe	0xfa8001b41b30	33	856	0	False	2025-04-26 00:01:17 UTC	N/A
964	448	svchost.exe	0xfa8001bcab30	14	304	0	False	2025-04-26 00:01:17 UTC	N/A
1076	448	spoolsv.exe	0xfa8001c37060	14	291	0	False	2025-04-26 00:01:18 UTC	N/A
1120	448	svchost.exe	0xfa8001c6cb30	20	318	0	False	2025-04-26 00:01:18 UTC	N/A
1232	448	taskhost.exe	0xfa8001d33b30	9	161	1	False	2025-04-26 00:01:19 UTC	N/A
1368	448	dwm.exe	0xfa8001d8eb30	4	72	1	False	2025-04-26 00:01:19 UTC	N/A
1404	1396	explorer.exe	0xfa8001e22b30	31	790	1	False	2025-04-26 00:01:19 UTC	N/A
1512	1404	svchost.exe	0xfa8001e70060	14	241	1	False	2025-04-26 02:15:02 UTC	N/A
1748	448	SearchIndexer.	0xfa8001f47b30	15	702	0	False	2025-04-26 00:01:22 UTC	N/A
2096	704	audiodg.exe	0xfa800203b060	7	128	0	False	2025-04-26 00:01:24 UTC	N/A
2344	448	svchost.exe	0xfa8002144b30	11	201	0	False	2025-04-26 00:01:26 UTC	N/A
2488	1404	cmd.exe	0xfa80021cdb30	1	20	1	False	2025-04-26 02:15:02 UTC	N/A
3212	2488	whoami.exe	0xfa80024e1060	0	0	1	False	2025-04-26 02:15:03 UTC	2025-04-26 02:15:03 UTC
3841	1404	svchost.exe	0xfa80027a4060	4	89	1	False	2025-04-26 02:15:11 UTC	N/A
4012	3841	conhost.exe	0xfa80028b2b30	2	53	1	False	2025-04-26 02:15:11 UTC	N/A
""",

    "windows.pstree": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
PID	PPID	ImageFileName	Offset	Threads	Handles	SessionId	Wow64	CreateTime	ExitTime

4	0	System	0xfa8000c9b040	95	411	N/A	False	2025-04-26 00:01:14 UTC	N/A
* 268	4	smss.exe	0xfa8001379980	2	29	N/A	False	2025-04-26 00:01:14 UTC	N/A
** 356	268	csrss.exe	0xfa800133b900	9	340	0	False	2025-04-26 00:01:15 UTC	N/A
** 396	268	wininit.exe	0xfa8001370b30	3	75	0	False	2025-04-26 00:01:15 UTC	N/A
*** 448	396	services.exe	0xfa80019b2b30	11	201	0	False	2025-04-26 00:01:15 UTC	N/A
**** 568	448	svchost.exe	0xfa8001a2eb30	10	347	0	False	2025-04-26 00:01:15 UTC	N/A
**** 636	448	svchost.exe	0xfa8001a6cb30	8	271	0	False	2025-04-26 00:01:16 UTC	N/A
**** 704	448	svchost.exe	0xfa8001aafb30	22	540	0	False	2025-04-26 00:01:16 UTC	N/A
**** 816	448	svchost.exe	0xfa8001b13060	14	365	0	False	2025-04-26 00:01:16 UTC	N/A
**** 856	448	svchost.exe	0xfa8001b41b30	33	856	0	False	2025-04-26 00:01:17 UTC	N/A
**** 964	448	svchost.exe	0xfa8001bcab30	14	304	0	False	2025-04-26 00:01:17 UTC	N/A
**** 1076	448	spoolsv.exe	0xfa8001c37060	14	291	0	False	2025-04-26 00:01:18 UTC	N/A
**** 1120	448	svchost.exe	0xfa8001c6cb30	20	318	0	False	2025-04-26 00:01:18 UTC	N/A
**** 1748	448	SearchIndexer.	0xfa8001f47b30	15	702	0	False	2025-04-26 00:01:22 UTC	N/A
**** 2344	448	svchost.exe	0xfa8002144b30	11	201	0	False	2025-04-26 00:01:26 UTC	N/A
*** 456	396	lsass.exe	0xfa80019b6b30	7	591	0	False	2025-04-26 00:01:15 UTC	N/A
*** 464	396	lsm.exe	0xfa80019c4060	10	142	0	False	2025-04-26 00:01:15 UTC	N/A
** 404	268	csrss.exe	0xfa800197d060	11	375	1	False	2025-04-26 00:01:15 UTC	N/A
** 448	268	services.exe	0xfa80019b2b30	11	201	0	False	2025-04-26 00:01:15 UTC	N/A
1404	1396	explorer.exe	0xfa8001e22b30	31	790	1	False	2025-04-26 00:01:19 UTC	N/A
* 1232	1404	taskhost.exe	0xfa8001d33b30	9	161	1	False	2025-04-26 00:01:19 UTC	N/A
* 1368	1404	dwm.exe	0xfa8001d8eb30	4	72	1	False	2025-04-26 00:01:19 UTC	N/A
* 2488	1404	cmd.exe	0xfa80021cdb30	1	20	1	False	2025-04-26 02:15:02 UTC	N/A
** 3212	2488	whoami.exe	0xfa80024e1060	0	0	1	False	2025-04-26 02:15:03 UTC	2025-04-26 02:15:03 UTC
* 3841	1404	svchost.exe	0xfa80027a4060	4	89	1	False	2025-04-26 02:15:11 UTC	N/A
** 4012	3841	conhost.exe	0xfa80028b2b30	2	53	1	False	2025-04-26 02:15:11 UTC	N/A
""",

    "windows.cmdline": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
PID	Process	Args

4	System	Required memory at 0xfa8000c9b040 is not valid (process exited?)
268	smss.exe	%SystemRoot%\\System32\\smss.exe
356	csrss.exe	%SystemRoot%\\system32\\csrss.exe ObjectDirectory=\\Windows SharedSection=1024,20480,768 Windows=On SubSystemType=Windows ServerDll=basesrv,1 ServerDll=winsrv:UserServerDllInitialization,3 ServerDll=winsrv:ConServerDllInitialization,2 ServerDll=sxssrv,4 ProfileControl=Off MaxRequestThreads=16
396	wininit.exe	wininit.exe
404	csrss.exe	%SystemRoot%\\system32\\csrss.exe ObjectDirectory=\\Windows SharedSection=1024,20480,768 Windows=On SubSystemType=Windows ServerDll=basesrv,1 ServerDll=winsrv:UserServerDllInitialization,3
448	services.exe	C:\\Windows\\system32\\services.exe
456	lsass.exe	C:\\Windows\\system32\\lsass.exe
464	lsm.exe	C:\\Windows\\system32\\lsm.exe
568	svchost.exe	C:\\Windows\\system32\\svchost.exe -k DcomLaunch
636	svchost.exe	C:\\Windows\\system32\\svchost.exe -k RPCSS
704	svchost.exe	C:\\Windows\\system32\\svchost.exe -k netsvcs
816	svchost.exe	C:\\Windows\\System32\\svchost.exe -k LocalServiceNetworkRestricted
856	svchost.exe	C:\\Windows\\System32\\svchost.exe -k LocalSystemNetworkRestricted
964	svchost.exe	C:\\Windows\\system32\\svchost.exe -k LocalService
1076	spoolsv.exe	C:\\Windows\\System32\\spoolsv.exe
1120	svchost.exe	C:\\Windows\\system32\\svchost.exe -k NetworkService
1232	taskhost.exe	taskhost.exe
1368	dwm.exe	Dwm.exe
1404	explorer.exe	C:\\Windows\\Explorer.EXE
1512	svchost.exe	C:\\Windows\\system32\\svchost.exe -k LocalServiceNetworkRestricted
1748	SearchIndexer.	C:\\Windows\\system32\\SearchIndexer.exe /Embedding
2096	audiodg.exe	C:\\Windows\\system32\\AUDIODG.EXE 0x2dc
2344	svchost.exe	C:\\Windows\\system32\\svchost.exe -k bthsvcs
2488	cmd.exe	cmd.exe /c whoami
3212	whoami.exe	whoami
3841	svchost.exe	C:\\Windows\\Temp\\upd8.exe --beacon --interval 30 --key 9f3a2b
4012	conhost.exe	\\??\\C:\\Windows\\system32\\conhost.exe 0x4
""",

    "windows.netstat": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
Offset	Proto	LocalAddr	LocalPort	ForeignAddr	ForeignPort	State	PID	Owner	Created

0xfa8001a2e4a0	TCPv4	10.14.3.22	49201	0.0.0.0	0	LISTENING	568	svchost.exe	2025-04-26 00:01:15 UTC
0xfa8001a6c4b0	TCPv4	10.14.3.22	135	0.0.0.0	0	LISTENING	636	svchost.exe	2025-04-26 00:01:16 UTC
0xfa8001aaf4c0	TCPv4	10.14.3.22	445	0.0.0.0	0	LISTENING	4	System	2025-04-26 00:01:16 UTC
0xfa8001b134d0	TCPv4	10.14.3.22	49152	0.0.0.0	0	LISTENING	396	wininit.exe	2025-04-26 00:01:16 UTC
0xfa8001b414e0	TCPv4	10.14.3.22	49153	0.0.0.0	0	LISTENING	456	lsass.exe	2025-04-26 00:01:17 UTC
0xfa8001bca4f0	TCPv4	10.14.3.22	49154	0.0.0.0	0	LISTENING	816	svchost.exe	2025-04-26 00:01:17 UTC
0xfa8001c37500	TCPv4	10.14.3.22	49155	0.0.0.0	0	LISTENING	1076	spoolsv.exe	2025-04-26 00:01:18 UTC
0xfa80027a4510	TCPv4	10.14.3.22	49688	91.108.56.201	4443	ESTABLISHED	3841	svchost.exe	2025-04-26 02:15:11 UTC
0xfa80028b2520	TCPv4	10.14.3.22	49689	91.108.56.201	4443	ESTABLISHED	3841	svchost.exe	2025-04-26 02:15:12 UTC
0xfa8001e22530	TCPv4	10.14.3.22	139	0.0.0.0	0	LISTENING	4	System	2025-04-26 00:01:19 UTC
0xfa8002144540	UDPv4	10.14.3.22	5355	*	*		2344	svchost.exe	2025-04-26 00:01:26 UTC
0xfa8001f47550	UDPv4	0.0.0.0	5004	*	*		1748	SearchIndexer.	2025-04-26 00:01:22 UTC
""",

    "windows.netscan": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
Offset	Proto	LocalAddr	LocalPort	ForeignAddr	ForeignPort	State	PID	Owner	Created

0xfa8001a2e4a0	TCPv4	10.14.3.22	49201	0.0.0.0	0	LISTENING	568	svchost.exe	2025-04-26 00:01:15 UTC
0xfa8001a6c4b0	TCPv4	10.14.3.22	135	0.0.0.0	0	LISTENING	636	svchost.exe	2025-04-26 00:01:16 UTC
0xfa8001aaf4c0	TCPv4	10.14.3.22	445	0.0.0.0	0	LISTENING	4	System	2025-04-26 00:01:16 UTC
0xfa80027a4510	TCPv4	10.14.3.22	49688	91.108.56.201	4443	ESTABLISHED	3841	svchost.exe	2025-04-26 02:15:11 UTC
0xfa80028b2520	TCPv4	10.14.3.22	49689	91.108.56.201	4443	ESTABLISHED	3841	svchost.exe	2025-04-26 02:15:12 UTC
0xfa8001e22530	TCPv4	10.14.3.22	139	0.0.0.0	0	LISTENING	4	System	2025-04-26 00:01:19 UTC
0xfa8001e22540	TCPv4	10.14.3.22	49201	185.220.101.47	44312	CLOSE_WAIT	3841	svchost.exe	2025-04-26 02:14:33 UTC
0xfa8002144540	UDPv4	10.14.3.22	5355	*	*		2344	svchost.exe	2025-04-26 00:01:26 UTC
0xfa8001f47550	UDPv4	0.0.0.0	5004	*	*		1748	SearchIndexer.	2025-04-26 00:01:22 UTC
0xfa8000c9b560	UDPv4	0.0.0.0	500	*	*		856	svchost.exe	2025-04-26 00:01:17 UTC
""",

    "windows.malfind": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
PID	Process	Start VPN	End VPN	Tag	Protection	CommitCharge	PrivateMemory	File output	Hexdump

3841	svchost.exe	0x400000	0x41ffff	VadS	PAGE_EXECUTE_READWRITE	512	1	Disabled
4d 5a 90 00 03 00 00 00 04 00 00 00 ff ff 00 00  MZ..............
b8 00 00 00 00 00 00 00 40 00 00 00 00 00 00 00  ........@.......
00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................
00 00 00 00 00 00 00 00 00 00 00 00 d0 00 00 00  ................
0e 1f ba 0e 00 b4 09 cd 21 b8 01 4c cd 21 54 68  ........!..L.!Th
ZmxhZ3tNZU0wclk= 00 00 00 00 00 00 00 00 00 00  ................
72 6f 67 72 61 6d 20 63 61 6e 6e 6f 74 20 62 65  rogram cannot be
20 72 75 6e 20 69 6e 20 44 4f 53 20 6d 6f 64 65   run in DOS mode
0d 0d 0a 24 00 00 00 00 00 00 00 00 00 00 00 00  ...$............
9c 34 d3 a8 f8 55 bd fb f8 55 bd fb f8 55 bd fb  .4...U...U...U..
e1 2f bc fb f9 55 bd fb 52 69 63 68 f8 55 bd fb  ./...U..Rich.U..

3841	svchost.exe	0x600000	0x61ffff	VadS	PAGE_EXECUTE_READWRITE	128	1	Disabled
00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00  ................
48 83 ec 28 48 8b 05 c7 5e 0c 00 48 85 c0 74 0c  H..(H...^..H..t.
ff d0 48 83 c4 28 c3 cc cc cc cc cc cc cc cc cc  ..H..(..........
""",

    "windows.dlllist_3841": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
PID	Process	Base	InLoad	InMem	InInit	Path

3841	svchost.exe	0x400000	True	True	True	C:\\Windows\\Temp\\upd8.exe
3841	svchost.exe	0x77af0000	True	True	True	C:\\Windows\\SYSTEM32\\ntdll.dll
3841	svchost.exe	0x75c40000	True	True	True	C:\\Windows\\system32\\kernel32.dll
3841	svchost.exe	0x75480000	True	True	True	C:\\Windows\\system32\\KERNELBASE.dll
3841	svchost.exe	0x760d0000	True	True	True	C:\\Windows\\system32\\ADVAPI32.dll
3841	svchost.exe	0x76990000	True	True	True	C:\\Windows\\system32\\msvcrt.dll
3841	svchost.exe	0x76960000	True	True	True	C:\\Windows\\SYSTEM32\\sechost.dll
3841	svchost.exe	0x76830000	True	True	True	C:\\Windows\\system32\\RPCRT4.dll
3841	svchost.exe	0x75220000	True	True	True	C:\\Windows\\system32\\WS2_32.dll
3841	svchost.exe	0x769f0000	True	True	True	C:\\Windows\\system32\\NSI.dll
3841	svchost.exe	0x6d9a0000	True	True	False	C:\\Windows\\Temp\\a9k.dll
3841	svchost.exe	0x756e0000	True	True	True	C:\\Windows\\system32\\USER32.dll
3841	svchost.exe	0x76560000	True	True	True	C:\\Windows\\system32\\GDI32.dll
3841	svchost.exe	0x77ab0000	True	True	True	C:\\Windows\\system32\\LPK.dll
3841	svchost.exe	0x76a00000	True	True	True	C:\\Windows\\system32\\USP10.dll
""",

    "windows.dlllist": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
PID	Process	Base	InLoad	InMem	InInit	Path

4	System	-	-	-	-	-
268	smss.exe	0x47b50000	True	True	True	\\Windows\\System32\\smss.exe
356	csrss.exe	0x77af0000	True	True	True	C:\\Windows\\SYSTEM32\\ntdll.dll
396	wininit.exe	0x77af0000	True	True	True	C:\\Windows\\SYSTEM32\\ntdll.dll
448	services.exe	0x77af0000	True	True	True	C:\\Windows\\SYSTEM32\\ntdll.dll
1404	explorer.exe	0x77af0000	True	True	True	C:\\Windows\\SYSTEM32\\ntdll.dll
3841	svchost.exe	0x400000	True	True	True	C:\\Windows\\Temp\\upd8.exe
3841	svchost.exe	0x6d9a0000	True	True	False	C:\\Windows\\Temp\\a9k.dll
Use --pid to filter by process ID
""",

    "windows.filescan": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
Offset	Name	Size

0xfa8001a4c070	\\Device\\HarddiskVolume2\\Windows\\System32\\ntdll.dll	1557504
0xfa8001b22080	\\Device\\HarddiskVolume2\\Windows\\System32\\kernel32.dll	860160
0xfa8001c44090	\\Device\\HarddiskVolume2\\Windows\\System32\\svchost.exe	27648
0xfa8001d550a0	\\Device\\HarddiskVolume2\\Windows\\System32\\lsass.exe	36352
0xfa8001e660b0	\\Device\\HarddiskVolume2\\Windows\\System32\\services.exe	259584
0xfa8001f770c0	\\Device\\HarddiskVolume2\\Windows\\System32\\explorer.exe	2871808
0xfa80020880d0	\\Device\\HarddiskVolume2\\Windows\\Temp\\upd8.exe	151552
0xfa80021990e0	\\Device\\HarddiskVolume2\\Windows\\Temp\\a9k.dll	45056
0xfa8002302170	\\Device\\HarddiskVolume2\\Users\\j.hartwell\\AppData\\Local\\Temp\\~tmp3f8a.dat	4096
0xfa8002413180	\\Device\\HarddiskVolume2\\Windows\\System32\\cmd.exe	302592
0xfa8002524190	\\Device\\HarddiskVolume2\\Windows\\System32\\whoami.exe	18432
0xfa80026351a0	\\Device\\HarddiskVolume2\\Users\\j.hartwell\\Desktop\\credentials.txt	0
Hex ref: 6e6f7468696e675f686572655f616e616c797374
0xfa80027461b0	\\Device\\HarddiskVolume2\\Windows\\System32\\conhost.exe	52736
0xfa80028571c0	\\Device\\HarddiskVolume2\\Windows\\System32\\SearchIndexer.exe	452608
""",

    "windows.hashdump": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
User	rid	lmhash	nthash

Administrator	500	aad3b435b51404eeaad3b435b51404ee	31d6cfe0d16ae931b73c59d7e0c089c0
Guest	501	aad3b435b51404eeaad3b435b51404ee	31d6cfe0d16ae931b73c59d7e0c089c0
j.hartwell	1001	aad3b435b51404eeaad3b435b51404ee	8846f7eaee8fb117ad06bdd830b7586c
svc_monitoring	1002	aad3b435b51404eeaad3b435b51404ee	e52cac67419a9a224a3b108f3fa6cb6d
ASTRS-WKS-014$	1003	aad3b435b51404eeaad3b435b51404ee	a87f3a337d73085c45f9416be5787d86
""",

    "windows.registry.hivelist": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
Offset	FileFullPath	File output

0xfffff8a000023010	\\REGISTRY\\MACHINE\\SYSTEM	Disabled
0xfffff8a0000491d0	\\REGISTRY\\MACHINE\\HARDWARE	Disabled
0xfffff8a000b682b0	\\REGISTRY\\USER\\.DEFAULT	Disabled
0xfffff8a000e1c730	\\REGISTRY\\MACHINE\\SAM	Disabled
0xfffff8a000e4b9d0	\\REGISTRY\\MACHINE\\SECURITY	Disabled
0xfffff8a0011db010	\\REGISTRY\\MACHINE\\SOFTWARE	Disabled
0xfffff8a001d61010	\\SystemRoot\\System32\\Config\\DEFAULT	Disabled
0xfffff8a001ff0400	\\REGISTRY\\USER\\S-1-5-21-3847709942-3764677621-4197646927-1001	Disabled
0xfffff8a002204370	\\REGISTRY\\USER\\S-1-5-21-3847709942-3764677621-4197646927-1001_Classes	Disabled
""",

    "windows.registry.printkey": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
Last Write Time	Hive Offset	Type	Key	Name	Data	Volatile

2025-04-26 02:15:09 UTC	0xfffff8a0011db010	Key	SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run	-	-	False
2025-04-26 02:15:09 UTC	0xfffff8a0011db010	REG_SZ	SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run	WindowsUpdate	C:\\Windows\\Temp\\upd8.exe --beacon --interval 30 --key 9f3a2b	False
2025-04-26 02:15:09 UTC	0xfffff8a0011db010	REG_SZ	SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run	SecurityHealth	%windir%\\system32\\SecurityHealthSystray.exe	False
2025-04-26 02:15:09 UTC	0xfffff8a0011db010	REG_SZ	SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run	VMware User Process	C:\\Program Files\\VMware\\VMware Tools\\vmtoolsd.exe -n vmusr	False
2025-04-26 02:15:09 UTC	0xfffff8a0011db010	REG_BINARY	SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SilentProcessExit\\upd8.exe	beacon_ref	ZmxhZ3t3cjBuZ19wYXRoX2FuYWx5c3R9	False
""",

    "windows.strings_3841": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
Scanning memory of PID 3841 (svchost.exe)...

0x400000	This program cannot be run in DOS mode
0x400010	.text
0x400018	.rdata
0x400020	.data
0x400028	.rsrc
0x401000	MSVCP140.dll
0x401010	VCRUNTIME140.dll
0x401020	api-ms-win-crt-runtime-l1-1-0.dll
0x401100	GetSystemTimeAsFileTime
0x401110	GetCurrentThreadId
0x401120	GetCurrentProcessId
0x401130	QueryPerformanceCounter
0x401200	IsProcessorFeaturePresent
0x401210	IsDebuggerPresent
0x401220	UnhandledExceptionFilter
0x401230	SetUnhandledExceptionFilter
0x401300	InitializeSListHead
0x401310	CreateThread
0x401320	ExitProcess
0x401400	WS2_32.dll
0x401410	WSAStartup
0x401420	WSACleanup
0x401430	socket
0x401500	connect
0x401510	send
0x401520	recv
0x401530	closesocket
0x401600	WINHTTP.dll
0x401610	WinHttpOpen
0x401620	WinHttpConnect
0x401700	WinHttpSendRequest
0x401710	WinHttpReceiveResponse
0x401800	beacon
0x401810	interval
0x401820	91.108.56.201
0x401830	4443
0x401900	--key
0x401910	9f3a2b
0x401a00	Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36
0x401b00	Content-Type: application/octet-stream
0x401c00	X-Session-Token:
0x401d00	upd8.exe
0x401e00	a9k.dll
0x401f00	C:\\Windows\\Temp\\
0x402000	kernel32.dll
0x402100	VirtualAlloc
0x402110	VirtualProtect
0x402120	CreateRemoteThread
0x402200	LoadLibraryA
0x402210	GetProcAddress
0x402300	SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run
0x402310	WindowsUpdate
0x402400	j.hartwell
0x402410	ASTRS-WKS-014
0x402500	NTLM
0x402510	NTLMv2
0x402600	SeDebugPrivilege
0x402610	SeImpersonatePrivilege
0x402700	cmd.exe
0x402710	whoami
0x402800	net user
0x402810	ipconfig
0x402900	tasklist
0x402a00	netstat -ano
0x402b00	systeminfo
0x402c00	dir C:\\Users
0x402d00	reg query HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run
0x402e00	schtasks /create
0x402f00	powershell -enc
0x403000	[beacon] initialising connection to C2
0x403100	[beacon] key exchange complete
0x403200	[beacon] session established
0x403300	[task] execute shell command
0x403400	[task] upload file
0x403500	[task] download file
0x403600	[task] inject process
0x403700	[task] dump credentials
0x403800	astraeus9-soc-prod
0x403900	j.hartwell@astraeus9.ops
0x403a00	185.220.101.47
0x403b00	encrypt
0x403c00	decrypt
0x403d00	AES-256-CBC
0x403e00	key_schedule
0x403f00	iv_generate
0x404000	RtlAdjustPrivilege
0x404100	NtQuerySystemInformation
0x404200	ZwCreateThreadEx
0x404300	MiniDumpWriteDump
0x404400	LSASS
0x404500	SAM
0x404600	SYSTEM
0x404700	credential_store
0x404800	hash_extract
0x404900	pass_the_hash
0x404a00	lateral_move
0x404b00	ASTRS-SRV-002
0x404c00	ASTRS-SRV-007
0x404d00	\\\\ASTRS-SRV-002\\C$
0x404e00	\\\\ASTRS-SRV-007\\C$
0x404f00	exfil_start
0x405000	exfil_complete
0x405100	c2.astraeus-exfil.net
0x405200	dns_tunnel
0x405300	base64_encode
0x405400	chunk_size
0x405500	dns_query
0x405600	[redacted_c2_ref_1]
0x405700	[redacted_c2_ref_2]
0x405800	session_id
0x405900	operator_id
0x405a00	campaign_id
0x405b00	implant_version
0x405c00	check_in_interval
0x405d00	max_retry
0x405e00	jitter
0x405f00	sleep_mask
0x406000	process_hollow
0x406100	dll_sideload
0x406200	reflective_load
0x406300	syscall_stub
0x406400	ntdll_unhook
0x406500	amsi_bypass
0x406600	etw_patch
0x406700	clr_disable
0x406800	event_log_clear
0x406900	shadow_copy_delete
0x406a00	vss_delete
0x406b00	wbadmin_delete
0x406c00	bcdedit_safeboot
0x406d00	recovery_disable
0x406e00	backup_delete
0x406f00	ZmxhZ3tNZU0wcllkdU1QaVNmdU5ufQ==
0x407000	task_complete
0x407100	session_close
0x407200	implant_exit
0x407300	[EOF]
""",

    "windows.strings": """
Volatility 3 Framework 2.4.1
Use --pid to filter by process ID
Example: windows.strings --pid 3841

Without a PID filter this operation would scan all process memory.
Specify a PID to extract strings from a specific process.
""",

    "windows.dumpfiles_3841": """
Volatility 3 Framework 2.4.1
Progress:  100.00               PDB scanning finished
Dumping files for PID 3841...

Cache	FileObject	FileName	Result

DataSectionObject	0xfa80020880d0	upd8.exe	file.0xfa80020880d0.0x400000.dat
ImageSectionObject	0xfa80020880d0	upd8.exe	file.0xfa80020880d0.0x400000.img
DataSectionObject	0xfa80021990e0	a9k.dll	file.0xfa80021990e0.0x6d9a0000.dat
ImageSectionObject	0xfa80021990e0	a9k.dll	file.0xfa80021990e0.0x6d9a0000.img

Note: Files written to output directory (simulation mode — files not available for download)
""",
}

def get_command_output(cmd):
    cmd = cmd.strip()

    # Exact matches
    if cmd in COMMANDS:
        return COMMANDS[cmd]

    # Parametric commands
    if '--pid 3841' in cmd and 'dlllist' in cmd:
        return COMMANDS["windows.dlllist_3841"]
    if '--pid 3841' in cmd and 'strings' in cmd:
        return COMMANDS["windows.strings_3841"]
    if '--pid 3841' in cmd and 'dumpfiles' in cmd:
        return COMMANDS["windows.dumpfiles_3841"]
    if '--pid' in cmd and 'dlllist' in cmd:
        pid = cmd.split('--pid')[-1].strip().split()[0]
        return f"\nVolatility 3 Framework 2.4.1\nNo results for PID {pid}\n"
    if '--pid' in cmd and 'strings' in cmd:
        pid = cmd.split('--pid')[-1].strip().split()[0]
        return f"\nVolatility 3 Framework 2.4.1\nNo results for PID {pid}\n"
    if '--pid' in cmd and 'malfind' in cmd:
        if '3841' in cmd:
            return COMMANDS["windows.malfind"]
        pid = cmd.split('--pid')[-1].strip().split()[0]
        return f"\nVolatility 3 Framework 2.4.1\nNo suspicious memory regions found for PID {pid}\n"

    # Base command with wrong args
    base = cmd.split()[0] if cmd.split() else cmd
    if base in [c.split()[0] for c in COMMANDS]:
        return f"\nVolatility 3 Framework 2.4.1\nError: Invalid arguments for {base}\nUse --help for usage information\n"

    # Unknown command
    return f"\nVolatility 3 Framework 2.4.1\nERROR: No plugin named '{cmd}'\nRun 'help' to see available plugins\n"

HELP_TEXT = """
Volatility 3 Framework 2.4.1

Available Plugins:

  windows.info              System information
  windows.pslist            Process list (flat)
  windows.pstree            Process list (tree view)
  windows.cmdline           Process command line arguments
  windows.netstat           Active network connections
  windows.netscan           Network connection scan
  windows.malfind           Find suspicious memory regions
  windows.dlllist           Loaded DLLs per process
  windows.filescan          File object scan
  windows.hashdump          Extract password hashes
  windows.strings           Extract strings from process memory
  windows.dumpfiles         Dump file objects
  windows.registry.hivelist List registry hives
  windows.registry.printkey Print registry key values

Optional arguments:
  --pid <PID>     Filter by process ID
  --output <dir>  Output directory for dumps

Examples:
  windows.pstree
  windows.cmdline --pid 3841
  windows.strings --pid 3841
  windows.malfind --pid 3841
  windows.dlllist --pid 3841
"""

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/run', methods=['POST'])
def run_command():
    cmd = request.json.get('command', '').strip()
    if not cmd:
        return jsonify({'output': '', 'error': True, 'msg': 'Empty command'})
    if cmd == 'help' or cmd == '--help':
        return jsonify({'output': HELP_TEXT, 'error': False})
    if cmd == 'clear':
        return jsonify({'output': '', 'error': False, 'clear': True})
    output = get_command_output(cmd)
    return jsonify({'output': output, 'error': False})

@app.route('/api/autocomplete', methods=['POST'])
def autocomplete():
    partial = request.json.get('partial', '')
    plugins = [
        'windows.info', 'windows.pslist', 'windows.pstree',
        'windows.cmdline', 'windows.netstat', 'windows.netscan',
        'windows.malfind', 'windows.dlllist', 'windows.filescan',
        'windows.hashdump', 'windows.strings', 'windows.dumpfiles',
        'windows.registry.hivelist', 'windows.registry.printkey',
    ]
    matches = [p for p in plugins if p.startswith(partial)]
    return jsonify({'matches': matches})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
