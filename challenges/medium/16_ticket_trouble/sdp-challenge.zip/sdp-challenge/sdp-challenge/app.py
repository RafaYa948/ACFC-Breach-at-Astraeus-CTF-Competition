from flask import Flask, render_template, request, jsonify, session

app = Flask(__name__)
app.secret_key = "astraeus9-sdp-acfc-2025-nottheflag"

TECHNICIANS = [
    "Syahmi Dinein",
    "Ameerah Hamid",
    "Irfan Ismail",
    "Haziq Muhammad",
    "Satheya Elangohvan",
    "Balasankar Chandrashakar",
]

TICKETS = [
    {
        "id": "ASTRAEUS-2041",
        "subject": "SMART121768 | Global IT PR T1098 NCR Windows User Account Enabled or Disabled",
        "requester": "SMART",
        "technician": "Ameerah Hamid",
        "group": "SOC L1",
        "status": "Closed",
        "priority": "High",
        "due_by": "2025-04-26 04:00:00",
        "created": "2025-04-25 22:11:04",
        "closed": "2025-04-26 03:44:12",
        "sla_status": "Met",
        "category": "Security Incident",
        "subcategory": "Authentication Anomaly",
        "description": "Zscaler proxy flagged unusual outbound traffic from ASTRS-WKS-009. Analyst reviewed and determined baseline deviation. No malicious payload detected.",
        "notes": [
            {"time": "2025-04-25 22:15:00", "author": "Ameerah Hamid", "text": "Reviewed Zscaler logs. Traffic volume 340% above baseline but destination is legitimate proxy endpoint. Ref: cmVzb2x1dGlvbl9yZWZfN2YzYQ=="},
            {"time": "2025-04-25 22:31:00", "author": "Ameerah Hamid", "text": "Confirmed benign. Closing as Benign Positive."},
        ],
        "history": [
            {"time": "2025-04-25 22:11:04", "action": "Ticket created", "by": "SOC System"},
            {"time": "2025-04-25 22:12:00", "action": "Assigned to Ameerah Hamid", "by": "SOC System"},
            {"time": "2025-04-26 03:44:12", "action": "Closed as Benign Positive", "by": "Ameerah Hamid"},
        ],
        "edit_history": [],
        "resolution": "Confirmed benign positive. Scheduled sync job.",
        "interactive": False,
    },
    {
        "id": "ASTRAEUS-2042",
        "subject": "HDM51654 | TI Map IP Entity to CommonSecurityLog",
        "requester": "HDM",
        "technician": "Irfan Ismail",
        "group": "SOC L1",
        "status": "In Progress",
        "priority": "High",
        "due_by": "2025-04-26 05:00:00",
        "created": "2025-04-26 00:04:17",
        "closed": None,
        "sla_status": "Met",
        "category": "Security Incident",
        "subcategory": "Threat Intelligence",
        "description": "Threat intelligence feed matched IP entity against CommonSecurityLog entries. Analyst reviewing correlated events across affected systems.",
        "notes": [
            {"time": "2025-04-26 00:09:00", "author": "Irfan Ismail", "text": "Correlated TI feed hit with network logs. Investigating affected endpoints. Ref: dGlja2V0X2hhc2hfOHgyYg=="},
        ],
        "history": [
            {"time": "2025-04-26 00:04:17", "action": "Ticket created", "by": "SOC System"},
            {"time": "2025-04-26 00:05:00", "action": "Assigned to Irfan Ismail", "by": "SOC System"},
        ],
        "edit_history": [],
        "resolution": None,
        "interactive": False,
    },
    {
        "id": "ASTRAEUS-2043",
        "subject": "EDOT486825 | Unfamiliar sign-in properties involving one user",
        "requester": "EDOT",
        "technician": "Irfan Ismail",
        "group": "SOC L1",
        "status": "Pending OpCo Verification",
        "priority": "High",
        "due_by": "2025-04-26 06:00:00",
        "created": "2025-04-26 00:17:33",
        "closed": None,
        "sla_status": "Met",
        "category": "Security Incident",
        "subcategory": "Identity Risk",
        "description": "Azure AD detected sign-in from unfamiliar location for user p.nakamura. MFA passed but IP geolocation flagged as anomalous. Pending OpCo verification of legitimate travel.",
        "notes": [
            {"time": "2025-04-26 00:22:00", "author": "Irfan Ismail", "text": "Contacted OpCo for user verification. Awaiting response. Ref: YXVkaXRfbG9nXzlrMWM="},
        ],
        "history": [
            {"time": "2025-04-26 00:17:33", "action": "Ticket created", "by": "SOC System"},
            {"time": "2025-04-26 00:18:00", "action": "Assigned to Irfan Ismail", "by": "SOC System"},
            {"time": "2025-04-26 00:22:00", "action": "Status changed to Pending OpCo Verification", "by": "Irfan Ismail"},
        ],
        "edit_history": [],
        "resolution": None,
        "interactive": False,
    },
    {
        "id": "ASTRAEUS-2044",
        "subject": "ADL116274 | Impossible travel activity involving one user",
        "requester": "ADL",
        "technician": "Irfan Ismail",
        "group": "SOC L1",
        "status": "Pending OpCo Verification",
        "priority": "High",
        "due_by": "2025-04-26 06:44:00",
        "created": "2025-04-26 00:44:21",
        "closed": None,
        "sla_status": "Met",
        "category": "Security Incident",
        "subcategory": "Identity Risk",
        "description": "Impossible travel alert — same user authenticated from Kuala Lumpur and Singapore within 8 minutes. Physically impossible. Credential compromise suspected. Pending OpCo verification.",
        "notes": [
            {"time": "2025-04-26 00:51:00", "author": "Irfan Ismail", "text": "Impossible travel confirmed — 8 minute gap, 350km distance. Sent verification request to OpCo. Ref: c2xhX3JlZl80cTdy"},
        ],
        "history": [
            {"time": "2025-04-26 00:44:21", "action": "Ticket created", "by": "SOC System"},
            {"time": "2025-04-26 00:45:00", "action": "Assigned to Irfan Ismail", "by": "SOC System"},
        ],
        "edit_history": [],
        "resolution": None,
        "interactive": False,
    },
    {
        "id": "ASTRAEUS-2045",
        "subject": "ADL116264 | NRT Authentication Methods Changed for VIP Users",
        "requester": "ADL",
        "technician": "Satheya Elangohvan",
        "group": "SOC L1",
        "status": "Pending OpCo Verification",
        "priority": "High",
        "due_by": "2025-04-26 07:00:00",
        "created": "2025-04-26 01:00:00",
        "closed": None,
        "sla_status": "Met",
        "category": "Security Incident",
        "subcategory": "Authentication Risk",
        "description": "Near real-time alert — MFA authentication methods changed for 3 VIP user accounts without change request. Possible credential compromise or insider threat.",
        "notes": [
            {"time": "2025-04-26 01:08:00", "author": "Satheya Elangohvan", "text": "Reviewing MFA change logs. Checking if change was authorised. Ref: cmVxdWVzdF9pZF82dDl1M3Y="},
        ],
        "history": [
            {"time": "2025-04-26 01:00:00", "action": "Ticket created", "by": "SOC System"},
            {"time": "2025-04-26 01:01:00", "action": "Assigned to Satheya Elangohvan", "by": "SOC System"},
        ],
        "edit_history": [],
        "resolution": None,
        "interactive": False,
    },
    {
        "id": "ASTRAEUS-2046",
        "subject": "SMART | Tor Exit Node Successful Authentication — ASTRS-WKS-014 — j.hartwell",
        "requester": "SMART",
        "technician": None,
        "group": "SOC L1",
        "status": "New",
        "priority": "Critical",
        "due_by": "2025-04-26 04:14:00",
        "created": "2025-04-26 02:14:33",
        "closed": None,
        "sla_status": "Breached",
        "sla_breach_minutes": 47,
        "category": "Security Incident",
        "subcategory": "Unauthorised Access",
        "description": "Successful authentication to the Astraeus-9 crew portal from IP 185.220.101.47 — a known Tor exit node flagged on 14 threat intelligence feeds. Account: j.hartwell. Post-login activity includes privilege assignment and process creation. This ticket was previously mishandled and closed prematurely. It has been re-opened for proper investigation.\n\nThis ticket requires immediate action:\n1. Pick Up the ticket and assign it to yourself\n2. Add a Work Note with your findings and correct classification\n3. Close the ticket with the correct resolution code",
        "notes": [
            {"time": "2025-04-26 02:20:00", "author": "SOC System", "text": "Ticket re-opened for investigation. Previous closure was inadequate. Awaiting analyst action."},
        ],
        "history": [
            {"time": "2025-04-26 02:14:33", "action": "Ticket created", "by": "SOC System"},
            {"time": "2025-04-26 02:14:45", "action": "Assigned to Ameerah Hamid", "by": "SOC System"},
            {"time": "2025-04-26 02:16:01", "action": "Reassigned to Irfan Ismail", "by": "Ameerah Hamid"},
            {"time": "2025-04-26 02:16:44", "action": "Reassigned — unverified assignment", "by": "Irfan Ismail"},
            {"time": "2025-04-26 02:28:11", "action": "Closed prematurely — insufficient investigation", "by": "Unknown"},
            {"time": "2025-04-26 03:55:00", "action": "Re-opened for investigation", "by": "Balasankar Chandrashakar"},
        ],
        "edit_history": [
            {"time": "2025-04-26 02:27:55", "author": "Unknown", "original": "537465616c557241454f4e — Attacker maintains active session. Lateral movement to ASTRS-SRV-002 detected. This is a Major Security Incident.", "edited_to": "Reviewed. No further action required."},
        ],
        "resolution": None,
        "interactive": True,
        "workflow_state": "new",
    },
    {
        "id": "ASTRAEUS-2047",
        "subject": "XL221684 | Global IT PR T1098 NCR Windows User Account Enabled or Disabled",
        "requester": "XL",
        "technician": "Irfan Ismail",
        "group": "SOC L1",
        "status": "Pending OpCo Verification",
        "priority": "High",
        "due_by": "2025-04-26 07:17:00",
        "created": "2025-04-26 01:17:00",
        "closed": None,
        "sla_status": "Met",
        "category": "Security Incident",
        "subcategory": "Account Management",
        "description": "NCR alert — Windows user account enabled or disabled outside approved change window. Requires OpCo verification to determine if change was authorised.",
        "notes": [
            {"time": "2025-04-26 01:22:00", "author": "Irfan Ismail", "text": "Checking with XL OpCo. Ref: ZXZlbnRfaGFzaF8ybTVuOHA="},
        ],
        "history": [
            {"time": "2025-04-26 01:17:00", "action": "Ticket created", "by": "SOC System"},
            {"time": "2025-04-26 01:18:00", "action": "Assigned to Irfan Ismail", "by": "SOC System"},
        ],
        "edit_history": [],
        "resolution": None,
        "interactive": False,
    },
    {
        "id": "ASTRAEUS-2048",
        "subject": "DGIT319460 | Imperva — Multiple user agents from same source",
        "requester": "DGIT",
        "technician": "Satheya Elangohvan",
        "group": "SOC L2",
        "status": "In Progress",
        "priority": "Critical",
        "due_by": "2025-04-26 06:38:00",
        "created": "2025-04-26 04:38:57",
        "closed": None,
        "sla_status": "Breached",
        "sla_breach_minutes": 67,
        "category": "Security Incident",
        "subcategory": "Data Exfiltration",
        "description": "Imperva WAF detected multiple user agents from same source IP targeting the Astraeus-9 web infrastructure. 847 requests in 18 minutes. Correlated with DNS tunnelling activity from ASTRS-SRV-002.",
        "notes": [
            {"time": "2025-04-26 04:50:00", "author": "Satheya Elangohvan", "text": "WAF logs confirmed. DNS tunnelling active. 2.3MB exfiltration confirmed. Resolution audit ref: dm91Y2hlcn0="},
        ],
        "history": [
            {"time": "2025-04-26 04:38:57", "action": "Ticket created", "by": "SOC System"},
            {"time": "2025-04-26 04:39:00", "action": "Assigned to Satheya Elangohvan", "by": "SOC System"},
        ],
        "edit_history": [],
        "resolution": None,
        "interactive": False,
    },
]

# ── ROUTES ─────────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html', tickets=TICKETS, technicians=TECHNICIANS)

@app.route('/ticket/<ticket_id>')
def ticket_detail(ticket_id):
    ticket = next((t for t in TICKETS if t['id'] == ticket_id), None)
    if not ticket:
        return "Ticket not found", 404
    if 'workflow' not in session:
        session['workflow'] = {}
    workflow_state = session['workflow'].get(ticket_id, 'new')
    return render_template('ticket.html', ticket=ticket,
                           technicians=TECHNICIANS,
                           workflow_state=workflow_state)

@app.route('/api/pickup/<ticket_id>', methods=['POST'])
def pickup(ticket_id):
    if ticket_id != 'ASTRAEUS-2046':
        return jsonify({'success': False, 'message': 'This ticket cannot be picked up.'})
    if 'workflow' not in session:
        session['workflow'] = {}
    state = session['workflow'].get(ticket_id, 'new')
    if state != 'new':
        return jsonify({'success': False, 'message': 'Ticket already picked up.'})
    session['workflow'][ticket_id] = 'picked_up'
    session.modified = True
    return jsonify({
        'success': True,
        'message': 'Ticket assigned to you. SLA timer restarted.',
        'state': 'picked_up'
    })

@app.route('/api/worknote/<ticket_id>', methods=['POST'])
def worknote(ticket_id):
    if ticket_id != 'ASTRAEUS-2046':
        return jsonify({'success': False, 'message': 'Action not available.'})
    if 'workflow' not in session:
        session['workflow'] = {}
    state = session['workflow'].get(ticket_id, 'new')
    if state == 'new':
        return jsonify({'success': False, 'message': 'You must pick up the ticket first.'})
    if state == 'noted':
        return jsonify({'success': False, 'message': 'Work note already added.'})

    classification = request.json.get('classification', '')
    correct_classifications = ['true positive', 'tp', 'true-positive']

    if classification.lower().strip() not in correct_classifications:
        return jsonify({
            'success': False,
            'message': 'Incorrect classification. Review the incident data carefully and try again.'
        })

    session['workflow'][ticket_id] = 'noted'
    session.modified = True
    return jsonify({
        'success': True,
        'message': 'Work note saved. Ticket updated.',
        'state': 'noted'
    })

@app.route('/api/close/<ticket_id>', methods=['POST'])
def close_ticket(ticket_id):
    if ticket_id != 'ASTRAEUS-2046':
        return jsonify({'success': False, 'message': 'Action not available.'})
    if 'workflow' not in session:
        session['workflow'] = {}
    state = session['workflow'].get(ticket_id, 'new')
    if state == 'new':
        return jsonify({'success': False, 'message': 'You must pick up the ticket first.'})
    if state == 'picked_up':
        return jsonify({'success': False, 'message': 'You must add a work note before closing.'})
    if state == 'closed':
        return jsonify({'success': False, 'message': 'Ticket already closed.'})

    resolution_code = request.json.get('resolution_code', '')
    correct_codes = ['security incident confirmed', 'true positive - security incident']

    if resolution_code.lower().strip() not in correct_codes:
        return jsonify({
            'success': False,
            'message': 'Incorrect resolution code. Select the appropriate closure reason.'
        })

    session['workflow'][ticket_id] = 'closed'
    session.modified = True
    return jsonify({
        'success': True,
        'message': 'Ticket closed successfully. System audit token generated.',
        'audit_token': 'ZmxhZ3tpd0lMTA==',
        'state': 'closed'
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
