from flask import Flask, request, render_template, session, redirect, url_for, jsonify
import sqlite3
import os
import re
import time

app = Flask(__name__)
app.secret_key = "astraeus9-sqli-2025-acfc-nottheflag"

DB_PATH = "/tmp/astraeus.db"

# ── WAF ───────────────────────────────────────────────────────────────────────
BLOCKED_KEYWORDS = [
    "union", "insert", "update", "delete", "drop",
    "--", "#", "xp_", "exec", "sleep", "benchmark",
    "load_file", "outfile", " "
]

def waf_check(value):
    value_lower = value.lower()
    for keyword in BLOCKED_KEYWORDS:
        if keyword in value_lower:
            return False
    return True

# ── DATABASE INIT ─────────────────────────────────────────────────────────────
def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()

    # Users table
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'crew'
        )
    """)

    # Crew table
    c.execute("""
        CREATE TABLE IF NOT EXISTS crew (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            rank TEXT NOT NULL,
            department TEXT NOT NULL,
            status TEXT DEFAULT 'active'
        )
    """)

    # Hidden secrets table — participants must find this
    c.execute("""
        CREATE TABLE IF NOT EXISTS classified (
            id INTEGER PRIMARY KEY,
            ref TEXT NOT NULL,
            data TEXT NOT NULL
        )
    """)

    # Insert users
    c.execute("DELETE FROM users")
    c.execute("INSERT INTO users VALUES (1, 'baboon', 'hehehehe', 'admin')")
    c.execute("INSERT INTO users VALUES (2, 'j.hartwell', 'Str0ngP@ss', 'crew')")
    c.execute("INSERT INTO users VALUES (3, 'svc_monitoring', 'M0n1t0r!ng', 'crew')")
    c.execute("INSERT INTO users VALUES (4, 'astrs_guest', 'guest123', 'guest')")

    # Insert crew
    c.execute("DELETE FROM crew")
    crew_members = [
        (1, "Imelia Ibrahim", "Senior Analyst", "SOC Operations", "active"),
        (2, "Firdaus Ghazali", "Senior Analyst", "SOC Operations", "active"),
        (3, "J. Hartwell", "Systems Operator", "Navigation", "compromised"),
        (4, "Umar Redza", "Senior Analyst", "SOC Operations", "active"),
        (5, "Roshean", "Senior Analyst", "SOC Operations", "active"),
        (6, "Prasad Jayabalan", "Head", "Security Architecture", "active"),
        (7, "Unknown Intruder", "???", "???", "inactive"),
    ]
    c.executemany("INSERT INTO crew VALUES (?,?,?,?,?)", crew_members)

    # Insert classified data — the flag is here
    c.execute("DELETE FROM classified")
    c.execute("INSERT INTO classified VALUES (1, 'TRANSMISSION-047', 'ACFC{sqL!sFUn(no_itSn0T)}')")
    c.execute("INSERT INTO classified VALUES (2, 'INCIDENT-REF', 'ASTRS-2025-IR-0047')")
    c.execute("INSERT INTO classified VALUES (3, 'ATTACKER-NOTE', 'You found me. But can you find what I left behind?')")

    conn.commit()
    conn.close()

# ── LOGIN ─────────────────────────────────────────────────────────────────────
@app.route("/", methods=["GET", "POST"])
def login():
    error = None
    waf_triggered = False

    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")

        # WAF check
        if not waf_check(username) or not waf_check(password):
            waf_triggered = True
            error = "Input blocked by security filter."
            return render_template("login.html", error=error, waf=waf_triggered)

        # Vulnerable query
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
            c.execute(query)
            user = c.fetchone()
            conn.close()

            if user:
                session["user"] = user[1]
                session["role"] = user[3]
                return redirect(url_for("dashboard"))
            else:
                error = "Invalid credentials. Access denied."
        except Exception as e:
            error = "Database error. Contact system administrator."

    return render_template("login.html", error=error, waf=waf_triggered)

# ── DASHBOARD ─────────────────────────────────────────────────────────────────
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM crew")
    crew = c.fetchall()
    conn.close()

    return render_template("dashboard.html",
                           user=session["user"],
                           role=session["role"],
                           crew=crew)

# ── SEARCH — BLIND SQLI ───────────────────────────────────────────────────────
@app.route("/search")
def search():
    if "user" not in session:
        return redirect(url_for("login"))

    query_term = request.args.get("q", "")
    results = []
    error = None

    if query_term:
        # WAF check on search too — but slightly different blocked list
        # Space is allowed here but UNION/SELECT still blocked
        search_blocked = ["union", "insert", "update", "delete",
                         "drop", "--", "attach", "detach"]
        blocked = any(kw in query_term.lower() for kw in search_blocked)

        if blocked:
            error = "Search term contains restricted keywords."
        else:
            try:
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                # Blind SQLi — only returns True/False based on row count
                # No data is shown — only "Found X results"
                query = f"SELECT COUNT(*) FROM crew WHERE name LIKE '%{query_term}%'"
                c.execute(query)
                count = c.fetchone()[0]
                conn.close()

                # Only reveal count — not actual data
                results = count

            except Exception as e:
                # Intentionally vague error
                error = "Search unavailable."
                results = 0

    return render_template("search.html",
                           user=session["user"],
                           results=results,
                           query=query_term,
                           error=error)

# ── LOGOUT ────────────────────────────────────────────────────────────────────
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=False)
